BAAZIGAR (Aryan Anees) - 3D Portfolio Website
==============================================

Files
- index.html  : poori website (ek hi file, dp andar embedded hai)
- robots.txt  : search engines ko allow karta hai

Kaise chalayein
1. Folder ko unzip karein.
2. index.html par double-click karein, browser mein khul jayegi.
   (3D ke liye internet chahiye, kyunke Three.js aur fonts online load hote hain.)

Online lagane ke free tareeqay
- Netlify: app.netlify.com/drop par poora folder drag-and-drop karein.
- Vercel ya GitHub Pages: folder upload karke deploy karein.
- Apna domain jodne ke baad Google Search Console mein site add karein
  aur URL submit karein, tab Google isay index karega.

Kya badalna ho to (index.html mein, text editor se)
- Instagram / Email / WhatsApp: "Pick a channel" section mein dhoondein
  (aryan_anees6, aryananees7@gmail.com, 923129498366).
- Projects ka text: id="projects" ke neeche.
- Rang: file ke shuru mein :root { --gold, --bg ... } mein.

Note: Contact details page par saaf likhi hain, to public hone par
spam aa sakta hai.
